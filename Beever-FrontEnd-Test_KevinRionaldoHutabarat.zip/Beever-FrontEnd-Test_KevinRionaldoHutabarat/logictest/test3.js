/*
Membeli makan siang dan menabung

Rusli adalah seorang anak sekolah di SD Beever
Setiap harinya, Rusli diberikan uang jajan oleh orang tuanya 
sebesar Rp. 10.000,- rupiah.

Rusli bisa menabung atau membeli makanan di sekolahnya untuk
makan siang. Kita telah diberikan catatan keuangan Rusli
dalam bentuk text biasa, dan kita diminta menghitung
jumlah uang tabungan Rusli per harinya dan total tabungannya.

OUTPUT:
{
    Senin: 2000,
    Selasa: 5500,
    Rabu: 3500,
    Kamis: 7000,
    Jumat: 5500,
    TotalTabungan: 23500
}

*/

function jumlahTabungan(listHarga, history) {
    let objBeli = history.split(".");
    let duit = 10000;
    let finalSisa = [];
    let finalHari = [];
    let finalResult = []
    let tabungan = 0;
    for(let i = 0; i<=objBeli.length-1; i++){
      let x = objBeli[i].split("-");
      let makan = x[1].split(",");
      let hari = String(x[0])
      finalHari.push(hari)
      let harga = 0
      for(let j = 0; j<=makan.length-1; j++){
        for(let k = 0; k<=listHarga.length-1; k++){
          if(makan[j] == listHarga[k].nama){
            harga = harga + listHarga[k].harga;
          }
        }
      }
      let sisa = duit - harga
      finalSisa.push(sisa);
    }
    for(let x = 0; x<=finalSisa.length-1;x++){
      tabungan = tabungan + finalSisa[x];
    }
    console.log("{")
    for(let y = 0; y<=finalHari.length-1;y++){
      console.log(`   ${finalHari[y]}: ${finalSisa[y]}`)
    }
    console.log(`   TotalTabungan: ${tabungan}`)
    console.log("}")  
}

var hargaMakanan = [
  {
    nama: "ayam",
    harga: 5000
  },
  {
    nama: "nasi",
    harga: 2000
  },
  {
    nama: "cola",
    harga: 1000
  },
  {
    nama: "chiki",
    harga: 1500
  },
  {
    nama: "hotdog",
    harga: 3000
  },
  {
    nama: "aqua",
    harga: 2000
  }
]

var historyPembelian = `Senin-ayam,nasi,cola.Selasa-chiki,hotdog.Rabu-ayam,chiki.Kamis-hotdog.Jumat-chiki,cola,nasi`
console.log(jumlahTabungan(hargaMakanan, historyPembelian))
