let words = "beever";

// Buatlah skema logika untuk memuat kata diatas menjadi berbentuk seperti berikut : 
// b
// be
// bee
// beev
// beeve
// beever

let input = words.split("")
let result = "";
for(let i = 0; i <= input.length-1; i++){
    result = result + words[i];
    console.log(result);
}