import React from 'react';

import { HomeView } from './components';
import './App.css';

function App() {
  return (
      <HomeView />

  );
}

export default App;
