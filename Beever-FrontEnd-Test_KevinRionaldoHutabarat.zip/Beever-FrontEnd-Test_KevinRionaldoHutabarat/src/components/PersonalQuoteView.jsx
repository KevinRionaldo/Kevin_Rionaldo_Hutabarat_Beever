import React from "react";

export default function PersonalQuoteView() {

  return (
    <section style={{ textAlign: "center", marginTop: "60px" }}>
      <hr style={{ maxWidth: "30%" }} />
      <h2>My Quotes</h2>
      <form >
        <input
        />
        <button
          type={`submit`}
        >
          Submit
        </button>
      </form>
    </section>
  );
}
