export { default as HomeView } from './HomeView';
export { default as KanyeQuoteView } from './KanyeQuoteView';
export { default as PersonalQuoteView } from './PersonalQuoteView';
